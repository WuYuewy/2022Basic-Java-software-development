import javafx.application.Application;
public class Main{
    public static void main(String []args){
        Application.launch(Game2048.class);
    }
}